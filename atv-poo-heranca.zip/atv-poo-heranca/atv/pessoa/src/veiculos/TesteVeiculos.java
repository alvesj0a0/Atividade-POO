package veiculos;

public class TesteVeiculos {
    public static void main(String[] args) {
        Veiculo[] frota = new Veiculo[3];

        frota[0] = new Carro("Toyota", "Corolla", 4);
        frota[1] = new Moto("Honda", "CB 500", 500);
        frota[2] = new Carro("Volkswagen", "Gol", 4);

        for (Veiculo v : frota) {
            v.exibirInfo();
            System.out.println("-----------------------");
        }
    }
}
