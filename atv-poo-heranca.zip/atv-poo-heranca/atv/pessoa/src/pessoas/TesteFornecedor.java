package pessoas;

public class TesteFornecedor {
    public static void main(String[] args) {
        Fornecedor f1 = new Fornecedor("João", "Belém", "9999-9999",
                5000.0, 1200.0);

        System.out.println("Nome: " + f1.getNome());
        System.out.println("Endereço: " + f1.getEndereco());
        System.out.println("Telefone: " + f1.getTelefone());
        System.out.println("Saldo disponível: R$ " + f1.obterSaldo());
    }
}
